<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/galerij/<?php echo e($foto->fotoid); ?>">
            <div class="row">
                <div class="col">
                    <img src="<?php echo e(asset($foto->fotoname)); ?>" alt="<?php echo e($foto->fotoid); ?>" height="200" width="350" onerror=this.src="<?php echo e(url('/img/img-placeholder.png')); ?>">
                </div>
                <div class="col">
                    <h3>Omschrijving</h3>
                    <p><?php echo e($foto->Omschrijving); ?></p>

                </div>
                <div class="col"></div>
            </div>
        </a>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/galerij.blade.php ENDPATH**/ ?>