<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="row">
        <div class="col"></div>
        <div class="col">
            <h3>New comment:</h3>
        </div>
        <div class="col"></div>
    </div>
    <br>
    <div class="row">
        <div class="col"></div>
        <div class="col">
            <form action="/addcomment/<?php echo e($foto->fotoid); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <textarea type="text" name="comment" class="form-control"  rows="8" cols="10"></textarea><br>
                <input type="hidden" name="username" value="<?php echo e(Auth::user()->name); ?>">
                <input type="submit" value="Plaatsen" class="btn btn-secondary">
            </form>
        </div>
        <div class="col"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/newcomment.blade.php ENDPATH**/ ?>