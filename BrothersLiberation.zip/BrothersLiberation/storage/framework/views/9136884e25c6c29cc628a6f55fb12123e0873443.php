<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="row">
        <div class="col">
            <h3><?php echo e($product->productnaam); ?></h3>
        </div>
        <div class="col" style="text-align:right">
            <?php if($user = Auth::user()): ?>
                <form action="/deleteproduct/<?php echo e($product->productid); ?>" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-secondary">Delete product</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col">
            <img src="<?php echo e($product->productimage); ?>" >
        </div>
        <div class="col">
            <h4>Categorie:</h4>
            <p><?php echo e($product->productcategorie); ?></p>
            <h4>Prijs:</h4>
            <p>€ <?php echo e($product->productprijs); ?></p>
            <h4>Omschrijving:</h4>
            <p><?php echo e($product->productomschrijving); ?></p>
            <br>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col">
            <a href="/addtocart/<?php echo e($product->productid); ?>">
                <button class="btn btn-secondary">Toevoegen aan winkelwagen</button>
            </a>
            &nbsp;&nbsp;
            <?php if($user = Auth::user()): ?>
                <a href="/editproduct/<?php echo e($product->productid); ?>">
                    <button class="btn btn-secondary">Product aanpassen</button>
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/product.blade.php ENDPATH**/ ?>