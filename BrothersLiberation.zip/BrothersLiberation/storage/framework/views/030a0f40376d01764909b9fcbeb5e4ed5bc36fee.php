<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="row">
        <div class="col">
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th scope="col">Productnaam</th>
                        <th scope="col">Aantal</th>
                        <th scope="col">Prijs</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($product['naam']); ?></th>
                            <td><?php echo e($product['aantal']); ?></td>
                            <td>€ <?php echo e($product['prijs']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <form action="/email" method="GET">
        <?php echo e(csrf_field()); ?>

        <br>
        <div class="row">
            <div class="col"></div>
            <div class="col">
                <br>
                <h5>Mail adres:</h5>
                <input type="email" name="mailadres" class="form-control">
                <br>
                <h5>Bericht:</h5>
                <textarea type="text" name="mailbody" class="form-control"  rows="8" cols="10"></textarea>
                <br><br>
                <input type="submit" class="btn btn-primary" value="Verzenden">
            </div>
            <div class="col"></div>
        </div>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/orderproduct.blade.php ENDPATH**/ ?>