<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="row filters">
        <div class="col">
            <select class="form-control" onchange="window.location=this.options[this.selectedIndex].value">
                <option disabled selected hidden>Maanden:</option>
                <option class="form-control" value="/agenda/filter/1">Januari</option>
                <option class="form-control" value="/agenda/filter/2">Februari</option>
                <option class="form-control" value="/agenda/filter/3">Maart</option>
                <option class="form-control" value="/agenda/filter/4">April</option>
                <option class="form-control" value="/agenda/filter/5">Mei</option>
                <option class="form-control" value="/agenda/filter/6">Juni</option>
                <option class="form-control" value="/agenda/filter/7">Juli</option>
                <option class="form-control" value="/agenda/filter/8">Augustus</option>
                <option class="form-control" value="/agenda/filter/9">September</option>
                <option class="form-control" value="/agenda/filter/10">Oktober</option>
                <option class="form-control" value="/agenda/filter/11">November</option>
                <option class="form-control" value="/agenda/filter/12">December</option>
                <option class="form-control" value="/agenda">Alle gebeurtenissen</option>
            </select>        
        </div>
        <div class="col">
            <form action='/agenda/date' method='GET'> 
                
                <?php echo e(csrf_field()); ?>

                <input type='date' class="form-control" onchange="this.form.submit()" name="date"/>
            </form>
        </div>
        <div class="col" style="text-align:right">
            <?php if($user = Auth::user()): ?>
                <a href="/nieuweactiviteit">
                    <button class="btn btn-secondary">Voeg activiteit toe</button>
                </a>
            <?php endif; ?>
        </div>
    </div>
    <br>
    <div class="row">
        <?php if(count($activiteiten) > 0): ?>
            <?php $__currentLoopData = $activiteiten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-4">
                    <a href="/gebeurtenis/<?php echo e($act->id); ?>">
                        <div class="card product">
                            <img src="<?php echo e(url('img/img-placeholder.png')); ?>" class="card-img-top">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($act->naam); ?></h5>
                                <p class="card-text"><?php echo e($act->starttijd); ?>  -  <?php echo e($act->eindtijd); ?></p>
                                <p class="card-text"><?php echo e($act->startdatum); ?>  -  <?php echo e($act->einddatum); ?></p>
                                <br>
                                <?php if($user = Auth::user()): ?>
                                    <a href="/delete/act/<?php echo e($act->id); ?>"><img src="/img/delete.jpg" height="30px" width="30px"></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <h3 style="margin-top:50px">Er zijn geen gebeurtenissen gevonden</h3>
        <?php endif; ?>
       
    </div>
    
</div>
<script type="text/javascript">
      $('#date1').change(function(){
        console.log('Submiting form');                
        $('#form1').submit();
      });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/agenda.blade.php ENDPATH**/ ?>