<?php $__env->startSection('content'); ?>
<div class="container ">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <br>
            <br>
            <div class="card homebody">
                <div class="card-header">Dashboard</div>

                <div class="card-body ">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <h5>Welkom</h5>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <a href="/nieuwlid">
                        <input type="submit" class="btn btn-secondary" value="Voeg nieuwe leden toe">
                        
                    </a>
                    <br>
                    <br>
                    
                    <h5>Webshop </h5>
                    <?php if($status->status == 1): ?>
                        <a href="/webshop_off">
                            <input type="submit" class="btn btn-danger" value="Zet webshop uit">
                        </a>
                    <?php else: ?>
                        <a href="/webshop_on">
                            <input type="submit" class="btn btn-success" value="Zet webshop aan">
                        </a>
                    <?php endif; ?>

                </div>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/home.blade.php ENDPATH**/ ?>