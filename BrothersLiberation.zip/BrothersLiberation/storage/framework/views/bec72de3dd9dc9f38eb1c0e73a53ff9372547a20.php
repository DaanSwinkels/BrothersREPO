<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="row">
        <div class="col">
            <img src="<?php echo e(asset($foto->fotoname)); ?>" alt="<?php echo e($foto->fotoid); ?>" height="200" width="350" onerror=this.src="<?php echo e(url('/img/img-placeholder.png')); ?>">
        </div>
        <div class="col">
            <h3>Omschrijving:</h3>
            <p><?php echo e($foto->Omschrijving); ?></p>
        </div>
        <div class="col"></div>
    </div>
    <br>
    <div class="row">
        <div class="col">
            <h3>Comments:</h3>
        </div>
        <div class="col" style="text-align:right">
            <?php if($user = Auth::user()): ?>
                <a href="/newcomment/<?php echo e($foto->fotoid); ?>">
                    <button class="btn btn-secondary">Nieuwe comment</button>
                </a>
            <?php else: ?>
                <a href="/login">
                    <button class="btn btn-secondary">Nieuwe comment</button>
                </a>
            <?php endif; ?>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col">
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user = Auth::user()): ?>
                    <a href="/comments/<?php echo e($comment->commentid); ?>" class="commentlink">
                        <div class="row align comment"> 
                            <div class="col"><p><?php echo e($comment->username); ?></p></div>
                            <div class="col-10"><?php echo e($comment->comment); ?></div>
                        </div>
                    </a>
                <?php else: ?>
                    <div class="row align comment">
                        <div class="col"><p><?php echo e($comment->username); ?></></div>
                        <div class="col-10"><?php echo e($comment->comment); ?></div>
                    </div>
                <?php endif; ?>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <br>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/Foto.blade.php ENDPATH**/ ?>