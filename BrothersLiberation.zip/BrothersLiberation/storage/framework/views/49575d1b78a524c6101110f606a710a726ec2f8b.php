<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <br>
    <div class="row">
        <div class="col">
            <h3>De webshop staat tijdelijk uit</h3>
        </div>
    </div>
    <br>
    <br>
    <div class="row">
        <div class="col" style="text-align:center">
                <img src="/img/brothersofliberation.png" alt="" height="400px" width="350px">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/404webshop.blade.php ENDPATH**/ ?>