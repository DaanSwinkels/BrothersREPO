<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <form action="/updatemember/<?php echo e($user->id); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="col"></div>
            <div class="col-5">
                <h3>Naam:</h3>
                <input type="text" name="naam" class="form-control" value="<?php echo e($user->name); ?>">
                <br>
                <h3>Bijnaam:</h3>
                <input type="text" name="bijnaam" class="form-control" value="<?php echo e($user->Bijnamen); ?>">
                <br>
                <h3>Email:</h3>
                <input type="text" name="email" class="form-control" value="<?php echo e($user->email); ?>">
            </div>
            <div class="col-5">
                <h3>Omschrijving:</h3>
                <textarea type="text" name="omschrijving" class="form-control"  rows="10" cols="10"><?php echo e($user->Omschrijving); ?></textarea>
                <br>
                <input type="submit" class="btn btn-primary" value="Update-">
            </div>
            <div class="col"></div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/editmember.blade.php ENDPATH**/ ?>