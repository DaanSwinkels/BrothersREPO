
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }
        
        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        
        tr:nth-child(even) {
            background-color: #dddddd;
        }
    </style>
</head>
<body>
    Beste <strong><?php echo e($name); ?></strong>,
    <br><br>
    <h3>Bestelling:</h3> 
        <table class="table">
            <thead>
                <tr>
                <th scope="col">Productnaam</th>
                <th scope="col">Aantal</th>
                <th scope="col">Prijs</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($product['naam']); ?></th>
                        <td><?php echo e($product['aantal']); ?></td>
                        <td>€ <?php echo e($product['prijs']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <p><?php echo e($body); ?></p>
        
</body>
</html>
<?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/testmail.blade.php ENDPATH**/ ?>