<?php $__env->startSection('content'); ?>
<div class="container">
    <br><br>
    <?php if(Auth::user()): ?>
        <?php $__currentLoopData = $leden; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/editmember/<?php echo e($lid->id); ?>">
                <div class="row align lid">
                    <div class="col-2">
                            <img class="lidimg" src="<?php echo e($lid->userimage); ?>" height="70px" width="120px">
                    </div>
                    <div  style="margin-top:10px;" class="col-2"><h5><?php echo e($lid->name); ?></h5></div>
                    <div style="margin-top:10px;" class="col-2"><?php echo e($lid->Bijnamen); ?></div>
                    <div style="margin-top:10px;" class="col-2"><?php echo e($lid->email); ?></div>
                    <div style="margin-top:10px;" class="col"><?php echo e($lid->Omschrijving); ?></div>
                </div>
            </a>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <?php $__currentLoopData = $leden; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row align lid">
                <div class="col-2">
                    <img class="lidimg" src="<?php echo e($lid->userimage); ?>" height="70px" width="120px">
                </div>
                <div  style="margin-top:10px;" class="col-2"><h5><?php echo e($lid->name); ?></h5></div>
                <div style="margin-top:10px;" class="col-2"><?php echo e($lid->Bijnamen); ?></div>
                <div style="margin-top:10px;" class="col-2"><?php echo e($lid->email); ?></div>
                <div style="margin-top:10px;" class="col"><?php echo e($lid->Omschrijving); ?></div>
            </div>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/leden.blade.php ENDPATH**/ ?>