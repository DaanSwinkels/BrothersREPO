<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col"></div>
        <div class="col">
            <h2>Nieuw lid</h2>
        </div>
        <div class="col"></div>
    </div>
    <br>
    <div class="row">
        <div class="col"></div>
        <div class="col">
            <form action="/adduser" method="POST">
                <?php echo method_field('POST'); ?>
                <?php echo e(csrf_field()); ?>

                <img aria-label="Product foto" id="imgShop" src="" onerror=this.src="<?php echo e(url('img/img-placeholder.png')); ?>" class="img-fluid" name="imagelink">
                <br><br>
                <input aria-label="Product foto toevoegen" type="file" name="image" onchange="previewFileShop()">
                <br>
                <br>
                <label>Gebruikersnaam:</label>
                <input type="text" name="name" class="form-control" required>
                <label>Bijnaam:</label>
                <input type="text" name="Bijnamen" class="form-control" required>
                <label>email:</label>
                <input type="text" name="email" class="form-control"  required>
                <label>Omschrijving:</label>
                <input type="text" name="Omschrijving" class="form-control" style="heigt:100px">
                <label>Wachtwoord:</label>
                <input type="password" name="password" class="form-control"  required>
                <br>
                <input type="submit" value="Toevoegen" class="btn btn-secondary">
            </form>
            
        </div>
        <div class="col"></div>

    </div>
    
    
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/newuser.blade.php ENDPATH**/ ?>