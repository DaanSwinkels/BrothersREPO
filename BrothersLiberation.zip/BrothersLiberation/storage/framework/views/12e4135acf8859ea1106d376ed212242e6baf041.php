<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="row">
        <div class="col">
            <h3><?php echo e($activiteit->naam); ?></h3>
        </div>
        <div class="col">
        </div>
        <div class="col" >
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col">
            <h5><?php echo e($activiteit->starttijd); ?>  -  <?php echo e($activiteit->eindtijd); ?></h5>
            <br>
            <h5><?php echo e($activiteit->startdatum); ?>  -  <?php echo e($activiteit->einddatum); ?></h5>
            <br>

            <?php if($user = Auth::user()): ?>
                <div id="edit" contenteditable="true">
                    <?php echo e($activiteit->omschrijving); ?>

                </div>
            <?php else: ?>
                <p><?php echo e($activiteit->omschrijving); ?></p>
            <?php endif; ?>
        </div>
        <div class="col">
            <?php if($user = Auth::user()): ?>
                <a href="/"><button class="btn btn-secondary">Aanpassen</button></a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script type="text/javascript">
    function saveEdits() {

        //get the editable element
        var editElem = document.getElementById("edit");

        //get the edited element content
        var userVersion = editElem.innerHTML;

        //save the content to local storage
        localStorage.userEdits = userVersion;

        //write a confirmation to the user
        document.getElementById("update").innerHTML="Edits saved!";

    }

</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/gebeurtenis.blade.php ENDPATH**/ ?>