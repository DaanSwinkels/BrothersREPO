<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <form action="/storeproduct" method="POST">
        <?php echo e(csrf_field()); ?>

        
        <br>
        <div class="row">
            <div class="col">
                <img src="/img/img-placeholder.png" >
            </div>
            <div class="col">
                <h4>Productnaam:</h4>
                <input type="text" name="name" class="form-control">
                <h4>Categorie:</h4>
                <input type="text" name="categorie" class="form-control">
                <h4>Prijs:</h4>
                <input type="text" name="prijs" class="form-control">
                <h4>Omschrijving:</h4>
                <textarea type="text" name="omschrijving" class="form-control"  rows="4" cols="10"></textarea><br>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col">
                <input type="submit" class="btn btn-primary" value="Toevoegen">
            </div>
        </div>
    </form>

    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/newproduct.blade.php ENDPATH**/ ?>