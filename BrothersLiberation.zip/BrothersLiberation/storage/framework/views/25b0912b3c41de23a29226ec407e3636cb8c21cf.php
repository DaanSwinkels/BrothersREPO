<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="row">
        <div class="col">
            <h2><?php echo e($user->name); ?></h2>
            <br>
            <h3>Bijnaam:</h3>
            <h5><?php echo e($user->Bijnamen); ?></h5>
            <br>
            <h3>Email:</h3>
            <h5><?php echo e($user->email); ?></h5>
            <br>
            <h3>Omschrijving:</h3>
            <p><?php echo e($user->Omschrijving); ?></p>
        </div>
        <div class="col">
            <img src="<?php echo e($user->userimage); ?>" onerror=this.src="<?php echo e(url('/img/img-placeholder.png')); ?>" height="200px" width="300px">
        </div>
    </div>
    <div class="row">
        <div class="col">
            <a href="/editmember/<?php echo e($user->id); ?>"><button class="btn btn-primary">Edit member</button> </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/lid.blade.php ENDPATH**/ ?>