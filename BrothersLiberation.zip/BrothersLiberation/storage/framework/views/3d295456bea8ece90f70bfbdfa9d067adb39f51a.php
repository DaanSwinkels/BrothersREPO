<?php $__env->startSection('content'); ?>

<div class="container-fluid ">
    <div class="row bol opc"> 
        <div class="col"></div>
        <div class="col boltext">
            <h1>Brothers of Liberations</h1>
            <h4>We are a brotherhood from the Netherlands. 🇳🇱</h5>
        </div>
        <div class="col"></div>
    </div>
</div>
<div class="container-fluid boloverons">
    <div id="hrline"></div>  
    <br>
    <div class="row">
        <div class="col"></div>
        <div class="col"><img src="/img/brothersofliberation.png" alt="" height="200px" width="150px"></div>
        <div class="col-9">
            <h1>Over ons</h1>
            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. 
            <br>
            <br>
            Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui.     
        </div>
        <div class="col"></div>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/welcome.blade.php ENDPATH**/ ?>