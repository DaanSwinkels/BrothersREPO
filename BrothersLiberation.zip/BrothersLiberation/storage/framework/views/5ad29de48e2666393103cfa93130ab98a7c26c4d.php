<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="row">
        <div class="col">
            <select class="form-control" onchange="window.location=this.options[this.selectedIndex].value">
                <option disabled selected hidden>Categorieën:</option>
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option class="form-control" value="/webshop/filter/<?php echo e($cat->productcategorie); ?>"><?php echo e($cat->productcategorie); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <option class="form-control" value="/webshop">Alle producten</option>

            </select>
        </div>
        <div class="col" >

        </div>
        <div class="col" style="text-align:right">
            <?php if($user = Auth::user()): ?>
                <a href="/newproduct">
                    <button class="btn btn-secondary">Nieuw product</button>
                </a>
            <?php endif; ?>
            &nbsp;&nbsp;
            <a href="/cart">
                <img src="<?php echo e(asset('img/cart.png')); ?>" height="50px" width="50px" >
            </a>
        </div>

    </div>
    <div class="row" >
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4">
                <div class="card product">
                    <img src="<?php echo e($product->productimage); ?>" class="card-img-top" >
                    <div class="card-body">
                    <h5 class="card-title"><?php echo e($product->productnaam); ?></h5>
                    <p class="card-text"><?php echo e($product->productcategorie); ?></p>
                    <p class="card-text">€ <?php echo e($product->productprijs); ?>,-</p>
                    <a href="/product/<?php echo e($product->productid); ?>" class="btn btn-primary">Bekijk product</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/webshop.blade.php ENDPATH**/ ?>