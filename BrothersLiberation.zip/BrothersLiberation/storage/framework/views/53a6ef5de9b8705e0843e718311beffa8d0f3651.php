<?php $__env->startSection('content'); ?>


<div class="container">
    <br>
    <div class="row">
        <div class="col">
            <h3>Winkelwagen</h3>
        </div>
        <div class="col">

        </div>
    </div>
    <br>
    <div class="row">
        <div class="col">
            <?php if(session('cart')): ?>
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th scope="col">Productnaam</th>
                            <th scope="col">Aantal</th>
                            <th scope="col">Prijs</th>
                            <th scope="col">Actie</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($details['naam']); ?></th>
                                <td><?php echo e($details['aantal']); ?></td>
                                <td>€ <?php echo e($details['prijs']); ?></td>
                                <td><a href="/removeitem/<?php echo e($id); ?>"> <img src="/img/delete.jpg" height="30px" width="30px"></a></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <br>
                <a href="/order"><button class="btn btn-secondary">Bestellen</button></a> &nbsp;&nbsp;
                <a href="/clearcart"><button class="btn btn-secondary">Winkewagen legen</button></a>
            <?php else: ?> 
                <br>
                <h5>Geen producten toegevoegd aan winkelwagen</h5>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projecten\LJ3\Per1\Brothers\BrothersLiberation\resources\views/cart.blade.php ENDPATH**/ ?>