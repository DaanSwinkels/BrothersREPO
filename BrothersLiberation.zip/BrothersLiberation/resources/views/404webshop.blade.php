@extends('layouts.app')

@section('content')
<div class="container">
    <br>
    <br>
    <div class="row">
        <div class="col">
            <h3>De webshop staat tijdelijk uit</h3>
        </div>
    </div>
    <br>
    <br>
    <div class="row">
        <div class="col" style="text-align:center">
                <img src="/img/brothersofliberation.png" alt="" height="400px" width="350px">
        </div>
    </div>
</div>
@endsection
