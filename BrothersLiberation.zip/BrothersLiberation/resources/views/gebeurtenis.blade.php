@extends('layouts.app')

@section('content')
<div class="container">
    <br>
    <div class="row">
        <div class="col">
            <h3>{{$activiteit->naam}}</h3>
        </div>
        <div class="col">
        </div>
        <div class="col" >
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col">
            <h5>{{$activiteit->starttijd}}  -  {{$activiteit->eindtijd}}</h5>
            <br>
            <h5>{{$activiteit->startdatum}}  -  {{$activiteit->einddatum}}</h5>
            <br>

            @if($user = Auth::user())
                <div id="edit" contenteditable="true">
                    {{$activiteit->omschrijving}}
                </div>
            @else
                <p>{{$activiteit->omschrijving}}</p>
            @endif
        </div>
        <div class="col">
            @if($user = Auth::user())
                <a href="/"><button class="btn btn-secondary">Aanpassen</button></a>
            @endif
        </div>
    </div>
</div>
@endsection

<script type="text/javascript">
    function saveEdits() {

        //get the editable element
        var editElem = document.getElementById("edit");

        //get the edited element content
        var userVersion = editElem.innerHTML;

        //save the content to local storage
        localStorage.userEdits = userVersion;

        //write a confirmation to the user
        document.getElementById("update").innerHTML="Edits saved!";

    }

</script>
